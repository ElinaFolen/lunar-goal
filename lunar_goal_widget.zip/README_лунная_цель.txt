ЛУННАЯ ЦЕЛЬ ДЛЯ DONATIONALERTS

В lunar_goal_widget.html уже встроена твоя розовая луна.

1. Зарегистрируй OAuth-приложение DonationAlerts.
2. Вставь Client ID вместо ВСТАВЬ_CLIENT_ID.
3. Redirect URI должен быть URL, по которому открывается этот HTML.
4. Нужны scopes: oauth-user-show и oauth-goal-subscribe.
5. Открой страницу, авторизуй DonationAlerts.
6. Добавь страницу в OBS как Browser Source.
7. Виджет показывает 10 лун; количество светящихся лун зависит от процента цели.

Не вставляй client_secret в HTML.
Для OAuth удобнее разместить HTML на статическом HTTPS-хостинге (например, GitHub Pages).
